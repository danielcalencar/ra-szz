package org.apache.regexp;

public class RESyntaxException
  extends RuntimeException
{
  public RESyntaxException(String paramString)
  {
    super("Syntax error: " + paramString);
  }
}
