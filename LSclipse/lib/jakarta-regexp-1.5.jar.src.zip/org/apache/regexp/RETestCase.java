package org.apache.regexp;

import java.io.ByteArrayInputStream;
import java.io.StringReader;

final class RETestCase
{
  private final StringBuffer log = new StringBuffer();
  private final int number;
  private final String tag;
  private final String pattern;
  private final String toMatch;
  private final boolean badPattern;
  private final boolean shouldMatch;
  private final String[] parens;
  private final RETest test;
  private RE regexp;
  
  public RETestCase(RETest paramRETest, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString)
  {
    this.number = (++paramRETest.testCount);
    this.test = paramRETest;
    this.tag = paramString1;
    this.pattern = paramString2;
    this.toMatch = paramString3;
    this.badPattern = paramBoolean1;
    this.shouldMatch = paramBoolean2;
    if (paramArrayOfString != null)
    {
      this.parens = new String[paramArrayOfString.length];
      System.arraycopy(paramArrayOfString, 0, this.parens, 0, paramArrayOfString.length);
    }
    else
    {
      this.parens = null;
    }
  }
  
  public void runTest()
  {
    this.test.say(this.tag + "(" + this.number + "): " + this.pattern);
    if (testCreation()) {
      testMatch();
    }
  }
  
  boolean testCreation()
  {
    try
    {
      this.regexp = new RE();
      this.regexp.setProgram(this.test.compiler.compile(this.pattern));
      if (this.badPattern)
      {
        this.test.fail(this.log, "Was expected to be an error, but wasn't.");
        return false;
      }
      return true;
    }
    catch (Exception localException)
    {
      if (this.badPattern)
      {
        this.log.append("   Match: ERR\n");
        success("Produces an error (" + localException.toString() + "), as expected.");
        return false;
      }
      String str = localException.getMessage() == null ? localException.toString() : localException.getMessage();
      this.test.fail(this.log, "Produces an unexpected exception \"" + str + "\"");
      localException.printStackTrace();
    }
    catch (Error localError)
    {
      this.test.fail(this.log, "Compiler threw fatal error \"" + localError.getMessage() + "\"");
      localError.printStackTrace();
    }
    return false;
  }
  
  private void testMatch()
  {
    this.log.append("   Match against: '").append(this.toMatch).append("'\n");
    try
    {
      boolean bool = this.regexp.match(this.toMatch);
      this.log.append("   Matched: ").append(bool ? "YES" : "NO").append("\n");
      if ((checkResult(bool)) && ((!this.shouldMatch) || (checkParens())))
      {
        this.log.append("   Match using StringCharacterIterator\n");
        if (!tryMatchUsingCI(new StringCharacterIterator(this.toMatch))) {
          return;
        }
        this.log.append("   Match using CharacterArrayCharacterIterator\n");
        if (!tryMatchUsingCI(new CharacterArrayCharacterIterator(this.toMatch.toCharArray(), 0, this.toMatch.length()))) {
          return;
        }
        this.log.append("   Match using StreamCharacterIterator\n");
        if (!tryMatchUsingCI(new StreamCharacterIterator(new ByteArrayInputStream(this.toMatch.getBytes())))) {
          return;
        }
        this.log.append("   Match using ReaderCharacterIterator\n");
        if (!tryMatchUsingCI(new ReaderCharacterIterator(new StringReader(this.toMatch)))) {
          return;
        }
      }
    }
    catch (Exception localException)
    {
      this.test.fail(this.log, "Matcher threw exception: " + localException.toString());
      localException.printStackTrace();
    }
    catch (Error localError)
    {
      this.test.fail(this.log, "Matcher threw fatal error \"" + localError.getMessage() + "\"");
      localError.printStackTrace();
    }
  }
  
  private boolean checkResult(boolean paramBoolean)
  {
    if (paramBoolean == this.shouldMatch)
    {
      success((this.shouldMatch ? "Matched" : "Did not match") + " \"" + this.toMatch + "\", as expected:");
      return true;
    }
    if (this.shouldMatch) {
      this.test.fail(this.log, "Did not match \"" + this.toMatch + "\", when expected to.");
    } else {
      this.test.fail(this.log, "Matched \"" + this.toMatch + "\", when not expected to.");
    }
    return false;
  }
  
  private boolean checkParens()
  {
    this.log.append("   Paren count: ").append(this.regexp.getParenCount()).append("\n");
    if (!assertEquals(this.log, "Wrong number of parens", this.parens.length, this.regexp.getParenCount())) {
      return false;
    }
    for (int i = 0; i < this.regexp.getParenCount(); i++)
    {
      this.log.append("   Paren ").append(i).append(": ").append(this.regexp.getParen(i)).append("\n");
      if (((!"null".equals(this.parens[i])) || (this.regexp.getParen(i) != null)) && (!assertEquals(this.log, "Wrong register " + i, this.parens[i], this.regexp.getParen(i)))) {
        return false;
      }
    }
    return true;
  }
  
  boolean tryMatchUsingCI(CharacterIterator paramCharacterIterator)
  {
    try
    {
      boolean bool = this.regexp.match(paramCharacterIterator, 0);
      this.log.append("   Match: ").append(bool ? "YES" : "NO").append("\n");
      return (checkResult(bool)) && ((!this.shouldMatch) || (checkParens()));
    }
    catch (Exception localException)
    {
      this.test.fail(this.log, "Matcher threw exception: " + localException.toString());
      localException.printStackTrace();
    }
    catch (Error localError)
    {
      this.test.fail(this.log, "Matcher threw fatal error \"" + localError.getMessage() + "\"");
      localError.printStackTrace();
    }
    return false;
  }
  
  public boolean assertEquals(StringBuffer paramStringBuffer, String paramString1, String paramString2, String paramString3)
  {
    if (((paramString2 != null) && (!paramString2.equals(paramString3))) || ((paramString3 != null) && (!paramString3.equals(paramString2))))
    {
      this.test.fail(paramStringBuffer, paramString1 + " (expected \"" + paramString2 + "\", actual \"" + paramString3 + "\")");
      return false;
    }
    return true;
  }
  
  public boolean assertEquals(StringBuffer paramStringBuffer, String paramString, int paramInt1, int paramInt2)
  {
    if (paramInt1 != paramInt2)
    {
      this.test.fail(paramStringBuffer, paramString + " (expected \"" + paramInt1 + "\", actual \"" + paramInt2 + "\")");
      return false;
    }
    return true;
  }
  
  void success(String paramString) {}
}
