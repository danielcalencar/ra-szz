package org.apache.regexp;

import java.applet.Applet;
import java.awt.Component;
import java.awt.Container;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextComponent;
import java.awt.TextField;
import java.awt.Window;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.CharArrayWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.EventObject;

public class REDemo
  extends Applet
  implements TextListener
{
  RE r = new RE();
  REDebugCompiler compiler = new REDebugCompiler();
  TextField fieldRE;
  TextField fieldMatch;
  TextArea outRE;
  TextArea outMatch;
  
  public void init()
  {
    GridBagLayout localGridBagLayout = new GridBagLayout();
    setLayout(localGridBagLayout);
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.insets = new Insets(5, 5, 5, 5);
    localGridBagConstraints.anchor = 13;
    localGridBagLayout.setConstraints(add(new Label("Regular expression:", 2)), localGridBagConstraints);
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.anchor = 17;
    localGridBagLayout.setConstraints(add(this.fieldRE = new TextField("\\[([:javastart:][:javapart:]*)\\]", 40)), localGridBagConstraints);
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = -1;
    localGridBagConstraints.anchor = 13;
    localGridBagLayout.setConstraints(add(new Label("String:", 2)), localGridBagConstraints);
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.gridx = -1;
    localGridBagConstraints.anchor = 17;
    localGridBagLayout.setConstraints(add(this.fieldMatch = new TextField("aaa([foo])aaa", 40)), localGridBagConstraints);
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.gridx = -1;
    localGridBagConstraints.fill = 1;
    localGridBagConstraints.weighty = 1.0D;
    localGridBagConstraints.weightx = 1.0D;
    localGridBagLayout.setConstraints(add(this.outRE = new TextArea()), localGridBagConstraints);
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.gridx = -1;
    localGridBagLayout.setConstraints(add(this.outMatch = new TextArea()), localGridBagConstraints);
    this.fieldRE.addTextListener(this);
    this.fieldMatch.addTextListener(this);
    textValueChanged(null);
  }
  
  void sayRE(String paramString)
  {
    this.outRE.setText(paramString);
  }
  
  void sayMatch(String paramString)
  {
    this.outMatch.setText(paramString);
  }
  
  String throwableToString(Throwable paramThrowable)
  {
    String str1 = paramThrowable.getClass().getName();
    String str2;
    if ((str2 = paramThrowable.getMessage()) != null) {
      str1 = str1 + "\n" + str2;
    }
    return str1;
  }
  
  void updateRE(String paramString)
  {
    try
    {
      this.r.setProgram(this.compiler.compile(paramString));
      CharArrayWriter localCharArrayWriter = new CharArrayWriter();
      this.compiler.dumpProgram(new PrintWriter(localCharArrayWriter));
      sayRE(localCharArrayWriter.toString());
      System.out.println(localCharArrayWriter);
    }
    catch (Exception localException)
    {
      this.r.setProgram(null);
      sayRE(throwableToString(localException));
    }
    catch (Throwable localThrowable)
    {
      this.r.setProgram(null);
      sayRE(throwableToString(localThrowable));
    }
  }
  
  void updateMatch(String paramString)
  {
    try
    {
      if (this.r.match(paramString))
      {
        String str = "Matches.\n\n";
        for (int i = 0; i < this.r.getParenCount(); i++) {
          str = str + "$" + i + " = " + this.r.getParen(i) + "\n";
        }
        sayMatch(str);
      }
      else
      {
        sayMatch("Does not match");
      }
    }
    catch (Throwable localThrowable)
    {
      sayMatch(throwableToString(localThrowable));
    }
  }
  
  public void textValueChanged(TextEvent paramTextEvent)
  {
    if ((paramTextEvent == null) || (paramTextEvent.getSource() == this.fieldRE)) {
      updateRE(this.fieldRE.getText());
    }
    updateMatch(this.fieldMatch.getText());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Frame localFrame = new Frame("RE Demo");
    localFrame.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        System.exit(0);
      }
    });
    REDemo localREDemo = new REDemo();
    localFrame.add(localREDemo);
    localREDemo.init();
    localFrame.pack();
    localFrame.setVisible(true);
  }
}
