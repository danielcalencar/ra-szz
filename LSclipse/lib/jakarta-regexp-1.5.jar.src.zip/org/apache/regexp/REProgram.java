package org.apache.regexp;

import java.io.Serializable;

public class REProgram
  implements Serializable
{
  static final int OPT_HASBACKREFS = 1;
  static final int OPT_HASBOL = 2;
  char[] instruction;
  int lenInstruction;
  char[] prefix;
  int flags;
  int maxParens = -1;
  
  public REProgram(char[] paramArrayOfChar)
  {
    this(paramArrayOfChar, paramArrayOfChar.length);
  }
  
  public REProgram(int paramInt, char[] paramArrayOfChar)
  {
    this(paramArrayOfChar, paramArrayOfChar.length);
  }
  
  public REProgram(char[] paramArrayOfChar, int paramInt)
  {
    setInstructions(paramArrayOfChar, paramInt);
  }
  
  public char[] getInstructions()
  {
    if (this.lenInstruction != 0)
    {
      char[] arrayOfChar = new char[this.lenInstruction];
      System.arraycopy(this.instruction, 0, arrayOfChar, 0, this.lenInstruction);
      return arrayOfChar;
    }
    return null;
  }
  
  public void setInstructions(char[] paramArrayOfChar, int paramInt)
  {
    this.instruction = paramArrayOfChar;
    this.lenInstruction = paramInt;
    this.flags = 0;
    this.prefix = null;
    if ((paramArrayOfChar != null) && (paramInt != 0))
    {
      if ((paramInt >= 3) && (paramArrayOfChar[0] == '|'))
      {
        i = (short)paramArrayOfChar[2];
        if ((paramArrayOfChar[(i + 0)] == 'E') && (paramInt >= 6))
        {
          int j = paramArrayOfChar[3];
          if (j == 65)
          {
            int k = paramArrayOfChar[4];
            this.prefix = new char[k];
            System.arraycopy(paramArrayOfChar, 6, this.prefix, 0, k);
          }
          else if (j == 94)
          {
            this.flags |= 0x2;
          }
        }
      }
      for (int i = 0; i < paramInt; i += 3) {
        switch (paramArrayOfChar[(i + 0)])
        {
        case '[': 
          i += paramArrayOfChar[(i + 1)] * '\002';
          break;
        case 'A': 
          i += paramArrayOfChar[(i + 1)];
          break;
        case '#': 
          this.flags |= 0x1;
          return;
        }
      }
    }
  }
  
  public char[] getPrefix()
  {
    if (this.prefix != null)
    {
      char[] arrayOfChar = new char[this.prefix.length];
      System.arraycopy(this.prefix, 0, arrayOfChar, 0, this.prefix.length);
      return arrayOfChar;
    }
    return null;
  }
}
