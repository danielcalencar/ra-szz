package org.apache.log4j.net;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.ErrorHandler;
import org.apache.log4j.spi.LoggingEvent;

public class SocketAppender
  extends AppenderSkeleton
{
  static final int DEFAULT_PORT = 4560;
  static final int DEFAULT_RECONNECTION_DELAY = 30000;
  String remoteHost;
  InetAddress address;
  int port = 4560;
  ObjectOutputStream oos;
  int reconnectionDelay = 30000;
  boolean locationInfo = false;
  private Connector connector;
  int counter = 0;
  private static final int RESET_FREQUENCY = 1;
  
  public SocketAppender() {}
  
  public SocketAppender(InetAddress address, int port)
  {
    this.address = address;
    this.remoteHost = address.getHostName();
    this.port = port;
    connect(address, port);
  }
  
  public SocketAppender(String host, int port)
  {
    this.port = port;
    this.address = getAddressByName(host);
    this.remoteHost = host;
    connect(this.address, port);
  }
  
  public void activateOptions()
  {
    connect(this.address, this.port);
  }
  
  public synchronized void close()
  {
    if (this.closed) {
      return;
    }
    this.closed = true;
    cleanUp();
  }
  
  public void cleanUp()
  {
    if (this.oos != null)
    {
      try
      {
        this.oos.close();
      }
      catch (IOException e)
      {
        LogLog.error("Could not close oos.", e);
      }
      this.oos = null;
    }
    if (this.connector != null)
    {
      this.connector.interrupted = true;
      this.connector = null;
    }
  }
  
  void connect(InetAddress address, int port)
  {
    if (this.address == null) {
      return;
    }
    try
    {
      cleanUp();
      this.oos = new ObjectOutputStream(new Socket(address, port).getOutputStream());
    }
    catch (IOException e)
    {
      LogLog.error("Could not connect to remote log4j server at [" + address.getHostName() + "]. We will try again later.", e);
      
      fireConnector();
    }
  }
  
  public void append(LoggingEvent event)
  {
    if (event == null) {
      return;
    }
    if (this.address == null)
    {
      this.errorHandler.error("No remote host is set for SocketAppender named \"" + this.name + "\".");
      
      return;
    }
    if (this.oos != null) {
      try
      {
        if (this.locationInfo) {
          event.getLocationInformation();
        }
        this.oos.writeObject(event);
        
        this.oos.flush();
        if (++this.counter >= 1)
        {
          this.counter = 0;
          
          this.oos.reset();
        }
      }
      catch (IOException e)
      {
        this.oos = null;
        LogLog.warn("Detected problem with connection: " + e);
        if (this.reconnectionDelay > 0) {
          fireConnector();
        }
      }
    }
  }
  
  void fireConnector()
  {
    if (this.connector == null)
    {
      LogLog.debug("Starting a new connector thread.");
      this.connector = new Connector();
      this.connector.setDaemon(true);
      this.connector.setPriority(1);
      this.connector.start();
    }
  }
  
  static InetAddress getAddressByName(String host)
  {
    try
    {
      return InetAddress.getByName(host);
    }
    catch (Exception e)
    {
      LogLog.error("Could not find address of [" + host + "].", e);
    }
    return null;
  }
  
  public boolean requiresLayout()
  {
    return false;
  }
  
  public void setRemoteHost(String host)
  {
    this.address = getAddressByName(host);
    this.remoteHost = host;
  }
  
  public String getRemoteHost()
  {
    return this.remoteHost;
  }
  
  public void setPort(int port)
  {
    this.port = port;
  }
  
  public int getPort()
  {
    return this.port;
  }
  
  public void setLocationInfo(boolean locationInfo)
  {
    this.locationInfo = locationInfo;
  }
  
  public boolean getLocationInfo()
  {
    return this.locationInfo;
  }
  
  public void setReconnectionDelay(int delay)
  {
    this.reconnectionDelay = delay;
  }
  
  public int getReconnectionDelay()
  {
    return this.reconnectionDelay;
  }
  
  class Connector
    extends Thread
  {
    boolean interrupted = false;
    
    Connector() {}
    
    public void run()
    {
      while (!this.interrupted) {
        try
        {
          Thread.sleep(SocketAppender.this.reconnectionDelay);
          LogLog.debug("Attempting connection to " + SocketAppender.this.address.getHostName());
          Socket socket = new Socket(SocketAppender.this.address, SocketAppender.this.port);
          synchronized (this)
          {
            SocketAppender.this.oos = new ObjectOutputStream(socket.getOutputStream());
            SocketAppender.this.connector = null;
            LogLog.debug("Connection established. Exiting connector thread.");
          }
        }
        catch (InterruptedException e)
        {
          LogLog.debug("Connector interrupted. Leaving loop.");
          return;
        }
        catch (ConnectException e)
        {
          LogLog.debug("Remote host " + SocketAppender.this.address.getHostName() + " refused connection.");
        }
        catch (IOException e)
        {
          LogLog.debug("Could not connect to " + SocketAppender.this.address.getHostName() + ". Exception is " + e);
        }
      }
    }
  }
}
