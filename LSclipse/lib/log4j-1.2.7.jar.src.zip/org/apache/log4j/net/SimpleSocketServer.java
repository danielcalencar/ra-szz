package org.apache.log4j.net;

import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import org.apache.log4j.Category;
import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;

public class SimpleSocketServer
{
  static Category cat = Category.getInstance(SimpleSocketServer.class.getName());
  static int port;
  
  public static void main(String[] argv)
  {
    if (argv.length == 2) {
      init(argv[0], argv[1]);
    } else {
      usage("Wrong number of arguments.");
    }
    try
    {
      cat.info("Listening on port " + port);
      ServerSocket serverSocket = new ServerSocket(port);
      for (;;)
      {
        cat.info("Waiting to accept a new client.");
        Socket socket = serverSocket.accept();
        cat.info("Connected to client at " + socket.getInetAddress());
        cat.info("Starting new socket node.");
        new Thread(new SocketNode(socket, LogManager.getLoggerRepository())).start();
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  static void usage(String msg)
  {
    System.err.println(msg);
    System.err.println("Usage: java " + SimpleSocketServer.class.getName() + " port configFile");
    
    System.exit(1);
  }
  
  static void init(String portStr, String configFile)
  {
    try
    {
      port = Integer.parseInt(portStr);
    }
    catch (NumberFormatException e)
    {
      e.printStackTrace();
      usage("Could not interpret port number [" + portStr + "].");
    }
    if (configFile.endsWith(".xml"))
    {
      new DOMConfigurator();DOMConfigurator.configure(configFile);
    }
    else
    {
      new PropertyConfigurator();PropertyConfigurator.configure(configFile);
    }
  }
}
