package org.apache.log4j.or;

class DefaultRenderer
  implements ObjectRenderer
{
  public String doRender(Object o)
  {
    return o.toString();
  }
}
