package org.apache.log4j.or;

public abstract interface ObjectRenderer
{
  public abstract String doRender(Object paramObject);
}
