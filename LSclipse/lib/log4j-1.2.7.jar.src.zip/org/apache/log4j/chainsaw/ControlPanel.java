package org.apache.log4j.chainsaw;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;
import org.apache.log4j.Category;
import org.apache.log4j.Priority;

class ControlPanel
  extends JPanel
{
  private static final Category LOG = Category.getInstance(ControlPanel.class);
  
  ControlPanel(MyTableModel aModel)
  {
    setBorder(BorderFactory.createTitledBorder("Controls: "));
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();
    setLayout(gridbag);
    
    c.ipadx = 5;
    c.ipady = 5;
    
    c.gridx = 0;
    c.anchor = 13;
    
    c.gridy = 0;
    JLabel label = new JLabel("Filter Level:");
    gridbag.setConstraints(label, c);
    add(label);
    
    c.gridy += 1;
    label = new JLabel("Filter Thread:");
    gridbag.setConstraints(label, c);
    add(label);
    
    c.gridy += 1;
    label = new JLabel("Filter Category:");
    gridbag.setConstraints(label, c);
    add(label);
    
    c.gridy += 1;
    label = new JLabel("Filter NDC:");
    gridbag.setConstraints(label, c);
    add(label);
    
    c.gridy += 1;
    label = new JLabel("Filter Message:");
    gridbag.setConstraints(label, c);
    add(label);
    
    c.weightx = 1.0D;
    
    c.gridx = 1;
    c.anchor = 17;
    
    c.gridy = 0;
    Priority[] allPriorities = Priority.getAllPossiblePriorities();
    JComboBox priorities = new JComboBox(allPriorities);
    Priority lowest = allPriorities[(allPriorities.length - 1)];
    priorities.setSelectedItem(lowest);
    aModel.setPriorityFilter(lowest);
    gridbag.setConstraints(priorities, c);
    add(priorities);
    priorities.setEditable(false);
    priorities.addActionListener(new ActionListener()
    {
      private final MyTableModel val$aModel;
      private final JComboBox val$priorities;
      
      public void actionPerformed(ActionEvent aEvent)
      {
        this.val$aModel.setPriorityFilter((Priority)this.val$priorities.getSelectedItem());
      }
    });
    c.fill = 2;
    c.gridy += 1;
    JTextField threadField = new JTextField("");
    threadField.getDocument().addDocumentListener(new DocumentListener()
    {
      private final MyTableModel val$aModel;
      private final JTextField val$threadField;
      
      public void insertUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setThreadFilter(this.val$threadField.getText());
      }
      
      public void removeUpdate(DocumentEvent aEvente)
      {
        this.val$aModel.setThreadFilter(this.val$threadField.getText());
      }
      
      public void changedUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setThreadFilter(this.val$threadField.getText());
      }
    });
    gridbag.setConstraints(threadField, c);
    add(threadField);
    
    c.gridy += 1;
    JTextField catField = new JTextField("");
    catField.getDocument().addDocumentListener(new DocumentListener()
    {
      private final MyTableModel val$aModel;
      private final JTextField val$catField;
      
      public void insertUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setCategoryFilter(this.val$catField.getText());
      }
      
      public void removeUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setCategoryFilter(this.val$catField.getText());
      }
      
      public void changedUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setCategoryFilter(this.val$catField.getText());
      }
    });
    gridbag.setConstraints(catField, c);
    add(catField);
    
    c.gridy += 1;
    JTextField ndcField = new JTextField("");
    ndcField.getDocument().addDocumentListener(new DocumentListener()
    {
      private final MyTableModel val$aModel;
      private final JTextField val$ndcField;
      
      public void insertUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setNDCFilter(this.val$ndcField.getText());
      }
      
      public void removeUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setNDCFilter(this.val$ndcField.getText());
      }
      
      public void changedUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setNDCFilter(this.val$ndcField.getText());
      }
    });
    gridbag.setConstraints(ndcField, c);
    add(ndcField);
    
    c.gridy += 1;
    JTextField msgField = new JTextField("");
    msgField.getDocument().addDocumentListener(new DocumentListener()
    {
      private final MyTableModel val$aModel;
      private final JTextField val$msgField;
      
      public void insertUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setMessageFilter(this.val$msgField.getText());
      }
      
      public void removeUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setMessageFilter(this.val$msgField.getText());
      }
      
      public void changedUpdate(DocumentEvent aEvent)
      {
        this.val$aModel.setMessageFilter(this.val$msgField.getText());
      }
    });
    gridbag.setConstraints(msgField, c);
    add(msgField);
    
    c.weightx = 0.0D;
    c.fill = 2;
    c.anchor = 13;
    c.gridx = 2;
    
    c.gridy = 0;
    JButton exitButton = new JButton("Exit");
    exitButton.setMnemonic('x');
    exitButton.addActionListener(ExitAction.INSTANCE);
    gridbag.setConstraints(exitButton, c);
    add(exitButton);
    
    c.gridy += 1;
    JButton clearButton = new JButton("Clear");
    clearButton.setMnemonic('c');
    clearButton.addActionListener(new ActionListener()
    {
      private final MyTableModel val$aModel;
      
      public void actionPerformed(ActionEvent aEvent)
      {
        this.val$aModel.clear();
      }
    });
    gridbag.setConstraints(clearButton, c);
    add(clearButton);
    
    c.gridy += 1;
    JButton toggleButton = new JButton("Pause");
    toggleButton.setMnemonic('p');
    toggleButton.addActionListener(new ActionListener()
    {
      private final MyTableModel val$aModel;
      private final JButton val$toggleButton;
      
      public void actionPerformed(ActionEvent aEvent)
      {
        this.val$aModel.toggle();
        this.val$toggleButton.setText(this.val$aModel.isPaused() ? "Resume" : "Pause");
      }
    });
    gridbag.setConstraints(toggleButton, c);
    add(toggleButton);
  }
}
