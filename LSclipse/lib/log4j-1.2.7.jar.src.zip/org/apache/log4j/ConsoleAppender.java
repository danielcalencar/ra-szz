package org.apache.log4j;

import java.io.OutputStreamWriter;
import org.apache.log4j.helpers.LogLog;

public class ConsoleAppender
  extends WriterAppender
{
  public static final String SYSTEM_OUT = "System.out";
  public static final String SYSTEM_ERR = "System.err";
  protected String target = "System.out";
  
  public ConsoleAppender() {}
  
  public ConsoleAppender(Layout layout)
  {
    this(layout, "System.out");
  }
  
  public ConsoleAppender(Layout layout, String target)
  {
    this.layout = layout;
    if ("System.out".equals(target)) {
      setWriter(new OutputStreamWriter(System.out));
    } else if ("System.err".equalsIgnoreCase(target)) {
      setWriter(new OutputStreamWriter(System.err));
    } else {
      targetWarn(target);
    }
  }
  
  public void setTarget(String value)
  {
    String v = value.trim();
    if ("System.out".equalsIgnoreCase(v)) {
      this.target = "System.out";
    } else if ("System.err".equalsIgnoreCase(v)) {
      this.target = "System.err";
    } else {
      targetWarn(value);
    }
  }
  
  public String getTarget()
  {
    return this.target;
  }
  
  void targetWarn(String val)
  {
    LogLog.warn("[" + val + "] should be System.out or System.err.");
    LogLog.warn("Using previously set target, System.out by default.");
  }
  
  public void activateOptions()
  {
    if (this.target.equals("System.out")) {
      setWriter(new OutputStreamWriter(System.out));
    } else {
      setWriter(new OutputStreamWriter(System.err));
    }
  }
  
  protected final void closeWriter() {}
}
