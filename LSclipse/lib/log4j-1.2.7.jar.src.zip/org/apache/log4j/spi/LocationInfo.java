package org.apache.log4j.spi;

import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import org.apache.log4j.Layout;
import org.apache.log4j.helpers.LogLog;

public class LocationInfo
  implements Serializable
{
  transient String lineNumber;
  transient String fileName;
  transient String className;
  transient String methodName;
  public String fullInfo;
  private static StringWriter sw = new StringWriter();
  private static PrintWriter pw = new PrintWriter(sw);
  public static final String NA = "?";
  static final long serialVersionUID = -1325822038990805636L;
  static boolean inVisualAge = false;
  
  static
  {
    try
    {
      Class dummy = Class.forName("com.ibm.uvm.tools.DebugSupport");
      inVisualAge = true;
      LogLog.debug("Detected IBM VisualAge environment.");
    }
    catch (Throwable e) {}
  }
  
  public LocationInfo(Throwable t, String fqnOfCallingClass)
  {
    if (t == null) {
      return;
    }
    String s;
    synchronized (sw)
    {
      t.printStackTrace(pw);
      s = sw.toString();
      sw.getBuffer().setLength(0);
    }
    int ibegin = s.lastIndexOf(fqnOfCallingClass);
    if (ibegin == -1) {
      return;
    }
    ibegin = s.indexOf(Layout.LINE_SEP, ibegin);
    if (ibegin == -1) {
      return;
    }
    ibegin += Layout.LINE_SEP_LEN;
    
    int iend = s.indexOf(Layout.LINE_SEP, ibegin);
    if (iend == -1) {
      return;
    }
    if (!inVisualAge)
    {
      ibegin = s.lastIndexOf("at ", iend);
      if (ibegin == -1) {
        return;
      }
      ibegin += 3;
    }
    this.fullInfo = s.substring(ibegin, iend);
  }
  
  public String getClassName()
  {
    if (this.fullInfo == null) {
      return "?";
    }
    if (this.className == null)
    {
      int iend = this.fullInfo.lastIndexOf('(');
      if (iend == -1)
      {
        this.className = "?";
      }
      else
      {
        iend = this.fullInfo.lastIndexOf('.', iend);
        
        int ibegin = 0;
        if (inVisualAge) {
          ibegin = this.fullInfo.lastIndexOf(' ', iend) + 1;
        }
        if (iend == -1) {
          this.className = "?";
        } else {
          this.className = this.fullInfo.substring(ibegin, iend);
        }
      }
    }
    return this.className;
  }
  
  public String getFileName()
  {
    if (this.fullInfo == null) {
      return "?";
    }
    if (this.fileName == null)
    {
      int iend = this.fullInfo.lastIndexOf(':');
      if (iend == -1)
      {
        this.fileName = "?";
      }
      else
      {
        int ibegin = this.fullInfo.lastIndexOf('(', iend - 1);
        this.fileName = this.fullInfo.substring(ibegin + 1, iend);
      }
    }
    return this.fileName;
  }
  
  public String getLineNumber()
  {
    if (this.fullInfo == null) {
      return "?";
    }
    if (this.lineNumber == null)
    {
      int iend = this.fullInfo.lastIndexOf(')');
      int ibegin = this.fullInfo.lastIndexOf(':', iend - 1);
      if (ibegin == -1) {
        this.lineNumber = "?";
      } else {
        this.lineNumber = this.fullInfo.substring(ibegin + 1, iend);
      }
    }
    return this.lineNumber;
  }
  
  public String getMethodName()
  {
    if (this.fullInfo == null) {
      return "?";
    }
    if (this.methodName == null)
    {
      int iend = this.fullInfo.lastIndexOf('(');
      int ibegin = this.fullInfo.lastIndexOf('.', iend);
      if (ibegin == -1) {
        this.methodName = "?";
      } else {
        this.methodName = this.fullInfo.substring(ibegin + 1, iend);
      }
    }
    return this.methodName;
  }
}
