package org.apache.log4j.spi;

public abstract interface OptionHandler
{
  public abstract void activateOptions();
}
