package org.apache.log4j.spi;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Hashtable;
import org.apache.log4j.Category;
import org.apache.log4j.Level;
import org.apache.log4j.MDC;
import org.apache.log4j.NDC;
import org.apache.log4j.Priority;
import org.apache.log4j.helpers.Loader;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.or.RendererMap;

public class LoggingEvent
  implements Serializable
{
  private static long startTime = ;
  public final transient String fqnOfCategoryClass;
  /**
   * @deprecated
   */
  private transient Category logger;
  /**
   * @deprecated
   */
  public final String categoryName;
  /**
   * @deprecated
   */
  public transient Priority level;
  private String ndc;
  private Hashtable mdcCopy;
  private boolean ndcLookupRequired = true;
  private boolean mdcCopyLookupRequired = true;
  private transient Object message;
  private String renderedMessage;
  private String threadName;
  private ThrowableInformation throwableInfo;
  public final long timeStamp;
  private LocationInfo locationInfo;
  static final long serialVersionUID = -868428216207166145L;
  static final Integer[] PARAM_ARRAY = new Integer[1];
  static final String TO_LEVEL = "toLevel";
  static final Class[] TO_LEVEL_PARAMS = { Integer.TYPE };
  static final Hashtable methodCache = new Hashtable(3);
  
  public LoggingEvent(String fqnOfCategoryClass, Category logger, Priority priority, Object message, Throwable throwable)
  {
    this.fqnOfCategoryClass = fqnOfCategoryClass;
    this.logger = logger;
    this.categoryName = logger.getName();
    this.level = priority;
    this.message = message;
    if (throwable != null) {
      this.throwableInfo = new ThrowableInformation(throwable);
    }
    this.timeStamp = System.currentTimeMillis();
  }
  
  public LoggingEvent(String fqnOfCategoryClass, Category logger, long timeStamp, Priority priority, Object message, Throwable throwable)
  {
    this.fqnOfCategoryClass = fqnOfCategoryClass;
    this.logger = logger;
    this.categoryName = logger.getName();
    this.level = priority;
    this.message = message;
    if (throwable != null) {
      this.throwableInfo = new ThrowableInformation(throwable);
    }
    this.timeStamp = timeStamp;
  }
  
  public LocationInfo getLocationInformation()
  {
    if (this.locationInfo == null) {
      this.locationInfo = new LocationInfo(new Throwable(), this.fqnOfCategoryClass);
    }
    return this.locationInfo;
  }
  
  public Level getLevel()
  {
    return (Level)this.level;
  }
  
  public String getLoggerName()
  {
    return this.categoryName;
  }
  
  public Object getMessage()
  {
    if (this.message != null) {
      return this.message;
    }
    return getRenderedMessage();
  }
  
  public String getNDC()
  {
    if (this.ndcLookupRequired)
    {
      this.ndcLookupRequired = false;
      this.ndc = NDC.get();
    }
    return this.ndc;
  }
  
  public Object getMDC(String key)
  {
    if (this.mdcCopy != null)
    {
      Object r = this.mdcCopy.get(key);
      if (r != null) {
        return r;
      }
    }
    return MDC.get(key);
  }
  
  public void getMDCCopy()
  {
    if (this.mdcCopyLookupRequired)
    {
      this.mdcCopyLookupRequired = false;
      
      Hashtable t = MDC.getContext();
      if (t != null) {
        this.mdcCopy = ((Hashtable)t.clone());
      }
    }
  }
  
  public String getRenderedMessage()
  {
    if ((this.renderedMessage == null) && (this.message != null)) {
      if ((this.message instanceof String))
      {
        this.renderedMessage = ((String)this.message);
      }
      else
      {
        LoggerRepository repository = this.logger.getHierarchy();
        if ((repository instanceof RendererSupport))
        {
          RendererSupport rs = (RendererSupport)repository;
          this.renderedMessage = rs.getRendererMap().findAndRender(this.message);
        }
        else
        {
          this.renderedMessage = this.message.toString();
        }
      }
    }
    return this.renderedMessage;
  }
  
  public static long getStartTime()
  {
    return startTime;
  }
  
  public String getThreadName()
  {
    if (this.threadName == null) {
      this.threadName = Thread.currentThread().getName();
    }
    return this.threadName;
  }
  
  public ThrowableInformation getThrowableInformation()
  {
    return this.throwableInfo;
  }
  
  public String[] getThrowableStrRep()
  {
    if (this.throwableInfo == null) {
      return null;
    }
    return this.throwableInfo.getThrowableStrRep();
  }
  
  private void readLevel(ObjectInputStream ois)
    throws IOException, ClassNotFoundException
  {
    int p = ois.readInt();
    try
    {
      String className = (String)ois.readObject();
      if (className == null)
      {
        this.level = Level.toLevel(p);
      }
      else
      {
        Method m = (Method)methodCache.get(className);
        if (m == null)
        {
          Class clazz = Loader.loadClass(className);
          
          m = clazz.getDeclaredMethod("toLevel", TO_LEVEL_PARAMS);
          methodCache.put(className, m);
        }
        PARAM_ARRAY[0] = new Integer(p);
        this.level = ((Level)m.invoke(null, PARAM_ARRAY));
      }
    }
    catch (Exception e)
    {
      LogLog.warn("Level deserialization failed, reverting to default.", e);
      this.level = Level.toLevel(p);
    }
  }
  
  private void readObject(ObjectInputStream ois)
    throws IOException, ClassNotFoundException
  {
    ois.defaultReadObject();
    readLevel(ois);
    if (this.locationInfo == null) {
      this.locationInfo = new LocationInfo(null, null);
    }
  }
  
  private void writeObject(ObjectOutputStream oos)
    throws IOException
  {
    getThreadName();
    
    getRenderedMessage();
    
    getNDC();
    
    getMDCCopy();
    
    getThrowableStrRep();
    
    oos.defaultWriteObject();
    
    writeLevel(oos);
  }
  
  private void writeLevel(ObjectOutputStream oos)
    throws IOException
  {
    oos.writeInt(this.level.toInt());
    
    Class clazz = this.level.getClass();
    if (clazz == Level.class) {
      oos.writeObject(null);
    } else {
      oos.writeObject(clazz.getName());
    }
  }
}
