package org.apache.log4j;

import java.util.Enumeration;
import org.apache.log4j.helpers.AppenderAttachableImpl;
import org.apache.log4j.helpers.BoundedFIFO;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.AppenderAttachable;
import org.apache.log4j.spi.LoggingEvent;

public class AsyncAppender
  extends AppenderSkeleton
  implements AppenderAttachable
{
  public static final int DEFAULT_BUFFER_SIZE = 128;
  BoundedFIFO bf = new BoundedFIFO(128);
  AppenderAttachableImpl aai;
  Dispatcher dispatcher;
  boolean locationInfo = false;
  boolean interruptedWarningMessage = false;
  
  public AsyncAppender()
  {
    this.aai = new AppenderAttachableImpl();
    this.dispatcher = new Dispatcher(this.bf, this);
    this.dispatcher.start();
  }
  
  public void addAppender(Appender newAppender)
  {
    synchronized (this.aai)
    {
      this.aai.addAppender(newAppender);
    }
  }
  
  public void append(LoggingEvent event)
  {
    event.getNDC();
    event.getThreadName();
    
    event.getMDCCopy();
    if (this.locationInfo) {
      event.getLocationInformation();
    }
    synchronized (this.bf)
    {
      while (this.bf.isFull()) {
        try
        {
          this.bf.wait();
        }
        catch (InterruptedException e)
        {
          if (!this.interruptedWarningMessage)
          {
            this.interruptedWarningMessage = true;
            LogLog.warn("AsyncAppender interrupted.", e);
          }
          else
          {
            LogLog.warn("AsyncAppender interrupted again.");
          }
        }
      }
      this.bf.put(event);
      if (this.bf.wasEmpty()) {
        this.bf.notify();
      }
    }
  }
  
  public void close()
  {
    synchronized (this)
    {
      if (this.closed) {
        return;
      }
      this.closed = true;
    }
    this.dispatcher.close();
    try
    {
      this.dispatcher.join();
    }
    catch (InterruptedException e)
    {
      LogLog.error("Got an InterruptedException while waiting for the dispatcher to finish.", e);
    }
    this.dispatcher = null;
    this.bf = null;
  }
  
  public Enumeration getAllAppenders()
  {
    synchronized (this.aai)
    {
      Enumeration localEnumeration = this.aai.getAllAppenders();return localEnumeration;
    }
  }
  
  public Appender getAppender(String name)
  {
    synchronized (this.aai)
    {
      Appender localAppender = this.aai.getAppender(name);return localAppender;
    }
  }
  
  public boolean getLocationInfo()
  {
    return this.locationInfo;
  }
  
  public boolean isAttached(Appender appender)
  {
    return this.aai.isAttached(appender);
  }
  
  public boolean requiresLayout()
  {
    return false;
  }
  
  public void removeAllAppenders()
  {
    synchronized (this.aai)
    {
      this.aai.removeAllAppenders();
    }
  }
  
  public void removeAppender(Appender appender)
  {
    synchronized (this.aai)
    {
      this.aai.removeAppender(appender);
    }
  }
  
  public void removeAppender(String name)
  {
    synchronized (this.aai)
    {
      this.aai.removeAppender(name);
    }
  }
  
  public void setLocationInfo(boolean flag)
  {
    this.locationInfo = flag;
  }
  
  public void setBufferSize(int size)
  {
    this.bf.resize(size);
  }
  
  public int getBufferSize()
  {
    return this.bf.getMaxSize();
  }
}
