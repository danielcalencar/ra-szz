package org.apache.log4j;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;
import java.util.Vector;
import org.apache.log4j.helpers.LogLog;

public class NDC
{
  static Hashtable ht = new Hashtable();
  static int pushCounter = 0;
  static final int REAP_THRESHOLD = 5;
  
  public static void clear()
  {
    Stack stack = (Stack)ht.get(Thread.currentThread());
    if (stack != null) {
      stack.setSize(0);
    }
  }
  
  public static Stack cloneStack()
  {
    Object o = ht.get(Thread.currentThread());
    if (o == null) {
      return null;
    }
    Stack stack = (Stack)o;
    return (Stack)stack.clone();
  }
  
  public static void inherit(Stack stack)
  {
    if (stack != null) {
      ht.put(Thread.currentThread(), stack);
    }
  }
  
  public static String get()
  {
    Stack s = (Stack)ht.get(Thread.currentThread());
    if ((s != null) && (!s.isEmpty())) {
      return ((DiagnosticContext)s.peek()).fullMessage;
    }
    return null;
  }
  
  public static int getDepth()
  {
    Stack stack = (Stack)ht.get(Thread.currentThread());
    if (stack == null) {
      return 0;
    }
    return stack.size();
  }
  
  private static void lazyRemove()
  {
    Vector v;
    synchronized (ht)
    {
      if (++pushCounter <= 5) {
        return;
      }
      pushCounter = 0;
      
      int misses = 0;
      v = new Vector();
      Enumeration enum = ht.keys();
      do
      {
        Thread t = (Thread)enum.nextElement();
        if (t.isAlive())
        {
          misses++;
        }
        else
        {
          misses = 0;
          v.addElement(t);
        }
        if (!enum.hasMoreElements()) {
          break;
        }
      } while (misses <= 4);
    }
    int size = v.size();
    for (int i = 0; i < size; i++)
    {
      Thread t = (Thread)v.elementAt(i);
      LogLog.debug("Lazy NDC removal for thread [" + t.getName() + "] (" + ht.size() + ").");
      
      ht.remove(t);
    }
  }
  
  public static String pop()
  {
    Thread key = Thread.currentThread();
    Stack stack = (Stack)ht.get(key);
    if ((stack != null) && (!stack.isEmpty())) {
      return ((DiagnosticContext)stack.pop()).message;
    }
    return "";
  }
  
  public static String peek()
  {
    Thread key = Thread.currentThread();
    Stack stack = (Stack)ht.get(key);
    if ((stack != null) && (!stack.isEmpty())) {
      return ((DiagnosticContext)stack.peek()).message;
    }
    return "";
  }
  
  public static void push(String message)
  {
    Thread key = Thread.currentThread();
    Stack stack = (Stack)ht.get(key);
    if (stack == null)
    {
      DiagnosticContext dc = new DiagnosticContext(message, null);
      stack = new Stack();
      ht.put(key, stack);
      stack.push(dc);
    }
    else if (stack.isEmpty())
    {
      DiagnosticContext dc = new DiagnosticContext(message, null);
      stack.push(dc);
    }
    else
    {
      DiagnosticContext parent = (DiagnosticContext)stack.peek();
      stack.push(new DiagnosticContext(message, parent));
    }
  }
  
  public static void remove()
  {
    ht.remove(Thread.currentThread());
    
    lazyRemove();
  }
  
  public static void setMaxDepth(int maxDepth)
  {
    Stack stack = (Stack)ht.get(Thread.currentThread());
    if ((stack != null) && (maxDepth < stack.size())) {
      stack.setSize(maxDepth);
    }
  }
  
  private static class DiagnosticContext
  {
    String fullMessage;
    String message;
    
    DiagnosticContext(String message, DiagnosticContext parent)
    {
      this.message = message;
      if (parent != null) {
        this.fullMessage = (parent.fullMessage + ' ' + message);
      } else {
        this.fullMessage = message;
      }
    }
  }
}
