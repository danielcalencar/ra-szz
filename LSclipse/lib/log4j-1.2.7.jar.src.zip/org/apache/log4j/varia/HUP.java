package org.apache.log4j.varia;

import java.net.ServerSocket;
import java.net.Socket;
import org.apache.log4j.helpers.LogLog;

class HUP
  extends Thread
{
  int port;
  ExternallyRolledFileAppender er;
  
  HUP(ExternallyRolledFileAppender er, int port)
  {
    this.er = er;
    this.port = port;
  }
  
  public void run()
  {
    while (!isInterrupted()) {
      try
      {
        ServerSocket serverSocket = new ServerSocket(this.port);
        for (;;)
        {
          Socket socket = serverSocket.accept();
          LogLog.debug("Connected to client at " + socket.getInetAddress());
          new Thread(new HUPNode(socket, this.er)).start();
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
}
