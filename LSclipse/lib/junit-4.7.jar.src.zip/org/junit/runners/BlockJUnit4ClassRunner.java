package org.junit.runners;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.Test.None;
import org.junit.internal.AssumptionViolatedException;
import org.junit.internal.runners.model.EachTestNotifier;
import org.junit.internal.runners.model.ReflectiveCallable;
import org.junit.internal.runners.statements.ExpectException;
import org.junit.internal.runners.statements.Fail;
import org.junit.internal.runners.statements.FailOnTimeout;
import org.junit.internal.runners.statements.InvokeMethod;
import org.junit.internal.runners.statements.RunAfters;
import org.junit.internal.runners.statements.RunBefores;
import org.junit.rules.MethodRule;
import org.junit.runner.Description;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.model.FrameworkField;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.Statement;
import org.junit.runners.model.TestClass;

public class BlockJUnit4ClassRunner
  extends ParentRunner<FrameworkMethod>
{
  public BlockJUnit4ClassRunner(Class<?> klass)
    throws InitializationError
  {
    super(klass);
  }
  
  protected void runChild(FrameworkMethod method, RunNotifier notifier)
  {
    EachTestNotifier eachNotifier = makeNotifier(method, notifier);
    if (method.getAnnotation(Ignore.class) != null)
    {
      eachNotifier.fireTestIgnored();
      return;
    }
    eachNotifier.fireTestStarted();
    try
    {
      methodBlock(method).evaluate();
    }
    catch (AssumptionViolatedException e)
    {
      eachNotifier.addFailedAssumption(e);
    }
    catch (Throwable e)
    {
      eachNotifier.addFailure(e);
    }
    finally
    {
      eachNotifier.fireTestFinished();
    }
  }
  
  protected Description describeChild(FrameworkMethod method)
  {
    return Description.createTestDescription(getTestClass().getJavaClass(), testName(method), method.getAnnotations());
  }
  
  protected List<FrameworkMethod> getChildren()
  {
    return computeTestMethods();
  }
  
  protected List<FrameworkMethod> computeTestMethods()
  {
    return getTestClass().getAnnotatedMethods(Test.class);
  }
  
  protected void collectInitializationErrors(List<Throwable> errors)
  {
    super.collectInitializationErrors(errors);
    
    validateConstructor(errors);
    validateInstanceMethods(errors);
    validateFields(errors);
  }
  
  protected void validateConstructor(List<Throwable> errors)
  {
    validateOnlyOneConstructor(errors);
    validateZeroArgConstructor(errors);
  }
  
  protected void validateOnlyOneConstructor(List<Throwable> errors)
  {
    if (!hasOneConstructor())
    {
      String gripe = "Test class should have exactly one public constructor";
      errors.add(new Exception(gripe));
    }
  }
  
  protected void validateZeroArgConstructor(List<Throwable> errors)
  {
    if ((hasOneConstructor()) && (getTestClass().getOnlyConstructor().getParameterTypes().length != 0))
    {
      String gripe = "Test class should have exactly one public zero-argument constructor";
      errors.add(new Exception(gripe));
    }
  }
  
  private boolean hasOneConstructor()
  {
    return getTestClass().getJavaClass().getConstructors().length == 1;
  }
  
  @Deprecated
  protected void validateInstanceMethods(List<Throwable> errors)
  {
    validatePublicVoidNoArgMethods(After.class, false, errors);
    validatePublicVoidNoArgMethods(Before.class, false, errors);
    validateTestMethods(errors);
    if (computeTestMethods().size() == 0) {
      errors.add(new Exception("No runnable methods"));
    }
  }
  
  private void validateFields(List<Throwable> errors)
  {
    for (FrameworkField each : ruleFields()) {
      validateRuleField(each.getField(), errors);
    }
  }
  
  private void validateRuleField(Field field, List<Throwable> errors)
  {
    if (!MethodRule.class.isAssignableFrom(field.getType())) {
      errors.add(new Exception("Field " + field.getName() + " must implement MethodRule"));
    }
    if (!Modifier.isPublic(field.getModifiers())) {
      errors.add(new Exception("Field " + field.getName() + " must be public"));
    }
  }
  
  protected void validateTestMethods(List<Throwable> errors)
  {
    validatePublicVoidNoArgMethods(Test.class, false, errors);
  }
  
  protected Object createTest()
    throws Exception
  {
    return getTestClass().getOnlyConstructor().newInstance(new Object[0]);
  }
  
  protected String testName(FrameworkMethod method)
  {
    return method.getName();
  }
  
  protected Statement methodBlock(FrameworkMethod method)
  {
    Object test;
    try
    {
      test = new ReflectiveCallable()
      {
        protected Object runReflectiveCall()
          throws Throwable
        {
          return BlockJUnit4ClassRunner.this.createTest();
        }
      }.run();
    }
    catch (Throwable e)
    {
      return new Fail(e);
    }
    Statement statement = methodInvoker(method, test);
    statement = possiblyExpectingExceptions(method, test, statement);
    statement = withPotentialTimeout(method, test, statement);
    statement = withRules(method, test, statement);
    statement = withBefores(method, test, statement);
    statement = withAfters(method, test, statement);
    return statement;
  }
  
  protected Statement methodInvoker(FrameworkMethod method, Object test)
  {
    return new InvokeMethod(method, test);
  }
  
  @Deprecated
  protected Statement possiblyExpectingExceptions(FrameworkMethod method, Object test, Statement next)
  {
    Test annotation = (Test)method.getAnnotation(Test.class);
    return expectsException(annotation) ? new ExpectException(next, getExpectedException(annotation)) : next;
  }
  
  @Deprecated
  protected Statement withPotentialTimeout(FrameworkMethod method, Object test, Statement next)
  {
    long timeout = getTimeout((Test)method.getAnnotation(Test.class));
    return timeout > 0L ? new FailOnTimeout(next, timeout) : next;
  }
  
  @Deprecated
  protected Statement withBefores(FrameworkMethod method, Object target, Statement statement)
  {
    List<FrameworkMethod> befores = getTestClass().getAnnotatedMethods(Before.class);
    return befores.isEmpty() ? statement : new RunBefores(statement, befores, target);
  }
  
  @Deprecated
  protected Statement withAfters(FrameworkMethod method, Object target, Statement statement)
  {
    List<FrameworkMethod> afters = getTestClass().getAnnotatedMethods(After.class);
    return afters.isEmpty() ? statement : new RunAfters(statement, afters, target);
  }
  
  private Statement withRules(FrameworkMethod method, Object target, Statement statement)
  {
    Statement result = statement;
    for (MethodRule each : rules(target)) {
      result = each.apply(result, method, target);
    }
    return result;
  }
  
  protected List<MethodRule> rules(Object test)
  {
    List<MethodRule> results = new ArrayList();
    for (FrameworkField each : ruleFields()) {
      results.add(createRule(test, each));
    }
    return results;
  }
  
  private List<FrameworkField> ruleFields()
  {
    return getTestClass().getAnnotatedFields(Rule.class);
  }
  
  private MethodRule createRule(Object test, FrameworkField each)
  {
    try
    {
      return (MethodRule)each.get(test);
    }
    catch (IllegalAccessException e)
    {
      throw new RuntimeException("How did getFields return a field we couldn't access?");
    }
  }
  
  private EachTestNotifier makeNotifier(FrameworkMethod method, RunNotifier notifier)
  {
    Description description = describeChild(method);
    return new EachTestNotifier(notifier, description);
  }
  
  private Class<? extends Throwable> getExpectedException(Test annotation)
  {
    if ((annotation == null) || (annotation.expected() == Test.None.class)) {
      return null;
    }
    return annotation.expected();
  }
  
  private boolean expectsException(Test annotation)
  {
    return getExpectedException(annotation) != null;
  }
  
  private long getTimeout(Test annotation)
  {
    if (annotation == null) {
      return 0L;
    }
    return annotation.timeout();
  }
}
