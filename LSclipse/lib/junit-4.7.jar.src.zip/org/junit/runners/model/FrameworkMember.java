package org.junit.runners.model;

import java.lang.annotation.Annotation;
import java.util.List;

abstract class FrameworkMember<T extends FrameworkMember<T>>
{
  abstract Annotation[] getAnnotations();
  
  abstract boolean isShadowedBy(T paramT);
  
  boolean isShadowedBy(List<T> members)
  {
    for (T each : members) {
      if (isShadowedBy(each)) {
        return true;
      }
    }
    return false;
  }
}
