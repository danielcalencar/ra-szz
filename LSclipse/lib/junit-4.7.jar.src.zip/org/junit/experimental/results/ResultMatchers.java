package org.junit.experimental.results;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.internal.matchers.TypeSafeMatcher;

public class ResultMatchers
{
  public static Matcher<PrintableResult> isSuccessful()
  {
    return failureCountIs(0);
  }
  
  public static Matcher<PrintableResult> failureCountIs(int count)
  {
    new TypeSafeMatcher()
    {
      public void describeTo(Description description)
      {
        description.appendText("has " + this.val$count + " failures");
      }
      
      public boolean matchesSafely(PrintableResult item)
      {
        return item.failureCount() == this.val$count;
      }
    };
  }
  
  public static Matcher<Object> hasSingleFailureContaining(String string)
  {
    new BaseMatcher()
    {
      public boolean matches(Object item)
      {
        return (item.toString().contains(this.val$string)) && (ResultMatchers.failureCountIs(1).matches(item));
      }
      
      public void describeTo(Description description)
      {
        description.appendText("has single failure containing " + this.val$string);
      }
    };
  }
  
  public static Matcher<PrintableResult> hasFailureContaining(String string)
  {
    new BaseMatcher()
    {
      public boolean matches(Object item)
      {
        return item.toString().contains(this.val$string);
      }
      
      public void describeTo(Description description)
      {
        description.appendText("has failure containing " + this.val$string);
      }
    };
  }
}
