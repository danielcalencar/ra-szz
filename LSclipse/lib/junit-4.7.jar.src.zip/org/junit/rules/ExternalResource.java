package org.junit.rules;

import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.Statement;

public abstract class ExternalResource
  implements MethodRule
{
  public final Statement apply(final Statement base, FrameworkMethod method, Object target)
  {
    new Statement()
    {
      public void evaluate()
        throws Throwable
      {
        ExternalResource.this.before();
        try
        {
          base.evaluate();
        }
        finally
        {
          ExternalResource.this.after();
        }
      }
    };
  }
  
  protected void before()
    throws Throwable
  {}
  
  protected void after() {}
}
