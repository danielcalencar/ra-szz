package org.junit.rules;

import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.Statement;

public class TestWatchman
  implements MethodRule
{
  public Statement apply(final Statement base, final FrameworkMethod method, Object target)
  {
    new Statement()
    {
      public void evaluate()
        throws Throwable
      {
        TestWatchman.this.starting(method);
        try
        {
          base.evaluate();
          TestWatchman.this.succeeded(method);
        }
        catch (Throwable t)
        {
          TestWatchman.this.failed(t, method);
          throw t;
        }
        finally
        {
          TestWatchman.this.finished(method);
        }
      }
    };
  }
  
  public void succeeded(FrameworkMethod method) {}
  
  public void failed(Throwable e, FrameworkMethod method) {}
  
  public void starting(FrameworkMethod method) {}
  
  public void finished(FrameworkMethod method) {}
}
