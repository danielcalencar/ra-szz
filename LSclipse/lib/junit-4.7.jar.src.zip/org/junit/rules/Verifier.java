package org.junit.rules;

import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.Statement;

public class Verifier
  implements MethodRule
{
  public Statement apply(final Statement base, FrameworkMethod method, Object target)
  {
    new Statement()
    {
      public void evaluate()
        throws Throwable
      {
        base.evaluate();
        Verifier.this.verify();
      }
    };
  }
  
  protected void verify()
    throws Throwable
  {}
}
