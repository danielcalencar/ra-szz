package org.junit.internal.runners.statements;

import org.junit.runners.model.Statement;

public class FailOnTimeout
  extends Statement
{
  private Statement fNext;
  private final long fTimeout;
  private boolean fFinished = false;
  private Throwable fThrown = null;
  
  public FailOnTimeout(Statement next, long timeout)
  {
    this.fNext = next;
    this.fTimeout = timeout;
  }
  
  public void evaluate()
    throws Throwable
  {
    Thread thread = new Thread()
    {
      public void run()
      {
        try
        {
          FailOnTimeout.this.fNext.evaluate();
          FailOnTimeout.this.fFinished = true;
        }
        catch (Throwable e)
        {
          FailOnTimeout.this.fThrown = e;
        }
      }
    };
    thread.start();
    thread.join(this.fTimeout);
    if (this.fFinished) {
      return;
    }
    if (this.fThrown != null) {
      throw this.fThrown;
    }
    Exception exception = new Exception(String.format("test timed out after %d milliseconds", new Object[] { Long.valueOf(this.fTimeout) }));
    
    exception.setStackTrace(thread.getStackTrace());
    throw exception;
  }
}
