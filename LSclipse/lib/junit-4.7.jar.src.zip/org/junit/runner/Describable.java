package org.junit.runner;

public abstract interface Describable
{
  public abstract Description getDescription();
}
