package org.junit.runner;

import java.util.ArrayList;
import java.util.List;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

public class Result
{
  private int fCount;
  private int fIgnoreCount;
  private final List<Failure> fFailures;
  private long fRunTime;
  private long fStartTime;
  
  public Result()
  {
    this.fCount = 0;
    this.fIgnoreCount = 0;
    this.fFailures = new ArrayList();
    this.fRunTime = 0L;
  }
  
  public int getRunCount()
  {
    return this.fCount;
  }
  
  public int getFailureCount()
  {
    return this.fFailures.size();
  }
  
  public long getRunTime()
  {
    return this.fRunTime;
  }
  
  public List<Failure> getFailures()
  {
    return this.fFailures;
  }
  
  public int getIgnoreCount()
  {
    return this.fIgnoreCount;
  }
  
  public boolean wasSuccessful()
  {
    return getFailureCount() == 0;
  }
  
  private class Listener
    extends RunListener
  {
    private Listener() {}
    
    public void testRunStarted(Description description)
      throws Exception
    {
      Result.this.fStartTime = System.currentTimeMillis();
    }
    
    public void testRunFinished(Result result)
      throws Exception
    {
      long endTime = System.currentTimeMillis();
      Result.access$114(Result.this, endTime - Result.this.fStartTime);
    }
    
    public void testFinished(Description description)
      throws Exception
    {
      Result.access$208(Result.this);
    }
    
    public void testFailure(Failure failure)
      throws Exception
    {
      Result.this.fFailures.add(failure);
    }
    
    public void testIgnored(Description description)
      throws Exception
    {
      Result.access$408(Result.this);
    }
    
    public void testAssumptionFailure(Failure failure) {}
  }
  
  public RunListener createListener()
  {
    return new Listener(null);
  }
}
