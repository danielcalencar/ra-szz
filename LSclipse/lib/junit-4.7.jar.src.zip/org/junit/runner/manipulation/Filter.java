package org.junit.runner.manipulation;

import org.junit.runner.Description;

public abstract class Filter
{
  public static Filter ALL = new Filter()
  {
    public boolean shouldRun(Description description)
    {
      return true;
    }
    
    public String describe()
    {
      return "all tests";
    }
  };
  
  public static Filter matchMethodDescription(Description desiredDescription)
  {
    new Filter()
    {
      public boolean shouldRun(Description description)
      {
        if (description.isTest()) {
          return this.val$desiredDescription.equals(description);
        }
        for (Description each : description.getChildren()) {
          if (shouldRun(each)) {
            return true;
          }
        }
        return false;
      }
      
      public String describe()
      {
        return String.format("Method %s", new Object[] { this.val$desiredDescription.getDisplayName() });
      }
    };
  }
  
  public abstract boolean shouldRun(Description paramDescription);
  
  public abstract String describe();
  
  public void apply(Object child)
    throws NoTestsRemainException
  {
    if (!(child instanceof Filterable)) {
      return;
    }
    Filterable filterable = (Filterable)child;
    filterable.filter(this);
  }
}
