package org.junit.runner.manipulation;

public abstract interface Sortable
{
  public abstract void sort(Sorter paramSorter);
}
