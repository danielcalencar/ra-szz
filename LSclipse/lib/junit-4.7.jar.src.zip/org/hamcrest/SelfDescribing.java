package org.hamcrest;

public abstract interface SelfDescribing
{
  public abstract void describeTo(Description paramDescription);
}
