package junit.framework;

public abstract interface Protectable
{
  public abstract void protect()
    throws Throwable;
}
