package junit.runner;

import java.io.PrintStream;

public class Version
{
  public static String id()
  {
    return "4.7";
  }
  
  public static void main(String[] args)
  {
    System.out.println(id());
  }
}
